# 圖片與素材

以下圖片為課程製作時的 AI 生成圖，不代表真實店家、人員或成果：

- `images/hero.jpg`
- `images/room.jpg`


