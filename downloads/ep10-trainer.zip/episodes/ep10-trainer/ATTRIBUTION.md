# 圖片與素材

本站圖片沿用本課程示範網站的圖片素材。

- `images/coach.jpg`
- `images/hero.jpg`
